
'use client';
import Link from 'next/link';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { cart } = useCart();

  return (
    <nav style={{ display:'flex', justifyContent:'space-between', padding:20 }}>
      <Link href='/'>Regent Row</Link>
      <div style={{ display:'flex', gap:20 }}>
        <Link href='/'>Home</Link>
        <Link href='/cart'>Cart ({cart.length})</Link>
      </div>
    </nav>
  );
}
