
export const products = [
  { id: "1", name: "Classic White Shirt", price: 59, image: "/p1.jpg", description: "Premium cotton shirt" },
  { id: "2", name: "Black Oversized Blazer", price: 129, image: "/p2.jpg", description: "Luxury fit blazer" },
  { id: "3", name: "Slim Fit Jeans", price: 89, image: "/p3.jpg", description: "Modern denim style" }
];
