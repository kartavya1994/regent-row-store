
import { products } from '../../../../lib/products';
import { notFound } from 'next/navigation';

export default function Product({ params }) {
  const product = products.find(p => p.id === params.id);
  if (!product) return notFound();

  return (
    <div style={{ padding:40 }}>
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <p>£{product.price}</p>
    </div>
  );
}
