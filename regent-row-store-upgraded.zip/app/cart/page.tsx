
'use client';
import { useCart } from '../../context/CartContext';

export default function CartPage() {
  const { cart } = useCart();

  return (
    <div style={{ padding:40 }}>
      <h1>Cart</h1>
      {cart.map((item, i) => (
        <div key={i}>
          {item.name} - £{item.price}
        </div>
      ))}
    </div>
  );
}
