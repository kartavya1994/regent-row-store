
import { products } from '../lib/products';
import Link from 'next/link';

export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Regent Row Store</h1>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:20 }}>
        {products.map(p => (
          <div key={p.id} style={{ border:'1px solid #ddd', padding:10 }}>
            <h3>{p.name}</h3>
            <p>£{p.price}</p>
            <Link href={'/product/' + p.id}>View</Link>
          </div>
        ))}
      </div>
    </main>
  );
}
